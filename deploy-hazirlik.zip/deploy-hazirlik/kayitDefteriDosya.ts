/**
 * Mühür kayıt defteri — GEÇİCİ dosya-tabanlı implementasyon.
 *
 * NEDEN VAR: kayitDefteri.ts'teki muhurKaydiGetir/muhurKaydiImzayilaGetir
 * fonksiyonları placeholder olarak throw ediyordu. Bu haliyle deploy edilirse
 * /v/{paketNo} sayfası — mühürlü PDF'lerin içine basılı TEK doğrulama linki —
 * her tıklamada 500 hatası verir. Bu, gerçek bir veritabanı bağlanana kadar
 * launch-blocking bir sorundu.
 *
 * BU DOSYA KALICI ÇÖZÜM DEĞİL. Dosya sistemine JSON yazan basit bir kayıt
 * tutucu — tek sunuculu / az trafikli bir başlangıç için yeterli, ama
 * yatay ölçeklenmeyi (birden fazla sunucu instance'ı) desteklemez ve
 * eşzamanlı yazmalarda veri kaybı riski taşır. Gerçek bir veritabanına
 * (Postgres/Firestore/DynamoDB) geçiş RM-006/007'nin bir sonraki turunda
 * yapılmalı — bu dosya o zamana kadar köprü görevi görür.
 */

import { promises as fs } from 'fs';
import path from 'path';
import type { MuhurKaydi } from './kayitDefteri';

const KAYIT_DIZINI =
  process.env.SKDM_KAYIT_DIZINI || path.join(process.cwd(), '.data', 'muhur-kayitlari');

async function dizinHazirla(): Promise<void> {
  await fs.mkdir(KAYIT_DIZINI, { recursive: true });
}

function guvenliDosyaAdi(paketNo: string): string {
  // Path traversal'a karşı — paket numarası zaten kalıba uymalı ama savunma
  // katmanı olarak alfasayısal + tire dışındaki her şeyi temizle.
  const temiz = paketNo.replace(/[^A-Za-z0-9-]/g, '');
  return `${temiz}.json`;
}

/** Mühürleme tamamlandığında ÇAĞRILMASI ZORUNLU — createSealedAuditPackage sonrası. */
export async function muhurKaydiYaz(kayit: MuhurKaydi): Promise<void> {
  await dizinHazirla();
  const dosyaYolu = path.join(KAYIT_DIZINI, guvenliDosyaAdi(kayit.paketNo));

  // Atomik yazma: önce geçici dosyaya, sonra rename. Yarım yazılmış
  // dosyanın okunmasını engeller.
  const gecici = `${dosyaYolu}.tmp-${process.pid}-${Date.now()}`;
  await fs.writeFile(gecici, JSON.stringify(kayit, null, 2), 'utf-8');
  await fs.rename(gecici, dosyaYolu);
}

export async function muhurKaydiGetirDosyadan(paketNo: string): Promise<MuhurKaydi | null> {
  const dosyaYolu = path.join(KAYIT_DIZINI, guvenliDosyaAdi(paketNo));
  try {
    const icerik = await fs.readFile(dosyaYolu, 'utf-8');
    return JSON.parse(icerik) as MuhurKaydi;
  } catch (e: any) {
    if (e?.code === 'ENOENT') return null;
    throw e;
  }
}

export async function muhurKaydiImzayilaGetirDosyadan(
  masterImza: string,
): Promise<MuhurKaydi | null> {
  await dizinHazirla();
  const temizImza = masterImza.trim().toLowerCase().replace(/^sha256:/, '');
  const dosyalar = await fs.readdir(KAYIT_DIZINI);

  for (const dosya of dosyalar) {
    if (!dosya.endsWith('.json') || dosya.includes('.tmp-')) continue;
    const icerik = await fs.readFile(path.join(KAYIT_DIZINI, dosya), 'utf-8');
    const kayit = JSON.parse(icerik) as MuhurKaydi;
    const kayitImza = kayit.masterImza.trim().toLowerCase().replace(/^sha256:/, '');
    if (kayitImza === temizImza) return kayit;
  }
  return null;
}
