#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════
# HEADER DÜZELTMESİ — logo + "Dosyama dön" mantıksızlığı
# ═══════════════════════════════════════════════════════════════════
set -euo pipefail

if [ ! -d "src/components" ]; then
  echo "HATA: repo kökünde değilsiniz." >&2
  exit 1
fi

echo "== 1) SiteHeader dosyasını buluyorum =="
HEADER=$(grep -rl "Dosyama dön\|skdm-logo-header" src/components --include="*.tsx" 2>/dev/null | head -1)
if [ -z "$HEADER" ]; then
  echo "  ✗ Ne 'Dosyama dön' ne logo referansı bulunamadı — dosya adı farklı olabilir."
  grep -rln "SiteHeader\|logo-header" src/components --include="*.tsx" 2>/dev/null
  exit 1
fi
echo "  Bulunan: $HEADER"

echo ""
echo "== 2) 'Dosyama dön' butonunun tam bağlamı =="
grep -n -B5 -A5 "Dosyama dön" "$HEADER"

echo ""
echo "== 3) Logo referansının tam bağlamı =="
grep -n -B3 -A3 "logo-header\|logo.*svg\|logo.*gif" "$HEADER" 2>/dev/null | head -30

echo ""
echo "== 4) DÜZELTME 1/2: Logo — .svg (statik) varsa animasyonlu .gif'e geri al =="
if grep -q "skdm-logo-header\.svg" "$HEADER"; then
  sed -i.bak "s|skdm-logo-header\.svg|skdm-logo-header-120.gif|g" "$HEADER"
  rm -f "$HEADER.bak"
  echo "  ✓ Statik SVG → animasyonlu GIF'e geri alındı"
else
  echo "  · Zaten .gif referansı var ya da farklı bir isimde — yukarıdaki 3. çıktıya bakın."
fi

echo ""
echo "== 5) DÜZELTME 2/2: 'Dosyama dön' — koşulsuz gösteriliyorsa koşullu yapılıyor =="
echo "  (Aktif taslak/oturum yoksa mantıksız — bu yüzden hasActiveDraft/user kontrolü aranıyor)"
if grep -B10 "Dosyama dön" "$HEADER" | grep -qE "hasActiveDraft|activeSession|draft &&|profile\?\."; then
  echo "  ✓ Zaten bir koşula bağlı görünüyor — 2. çıktıdaki bağlamı kontrol edin, güvenli."
else
  echo "  ✗ KOŞULSUZ GÖSTERİLİYOR OLABİLİR — yukarıdaki 2. çıktıdaki tam JSX'i bana gönderin,"
  echo "    doğru koşulu (hangi state/prop'a bağlanacağını) o gerçek koddan görüp tek satırlık"
  echo "    kesin patch'i yazacağım. Körlemesine buton metnini değiştirmek yanlış olabilir —"
  echo "    asıl sorun metin değil, HER SAYFADA koşulsuz görünmesi."
fi

echo ""
echo "== 6) Build ile doğrula =="
npx tsc --noEmit
npm run build
